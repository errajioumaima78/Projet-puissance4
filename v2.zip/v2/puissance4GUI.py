import tkinter as tk
from puissance4 import Puissance4 

class Puissance4GUI:
    def __init__(self, fenetre_principale, joueur1, joueur2, joueur_commence): 
        self.fenetre_principale = fenetre_principale
        self.fenetre_principale.title('Puissance 4')
        self.fenetre_principale.configure(bg='#18534F')
        
        self.joueur1 = joueur1
        self.joueur2 = joueur2
        self.jeu = Puissance4(joueur1, joueur2, joueur_commence)
        
        # Créer un cadre pour le jeu
        self.canvas = tk.Canvas(self.fenetre_principale, width=7*100, height=6*100)
        self.canvas.pack(pady=40)
        
        # Définir le label pour les messages
        self.message_label = tk.Label(self.fenetre_principale, text="", font=('Caviar Dreams', 30), bg='#18534F', fg='#FEEAA1')
        self.message_label.pack(pady=20)
        
        self.bouton_recommencer = tk.Button(self.fenetre_principale, text="Recommencer", font=('Caviar Dreams', 30), bg='#FEEAA1', fg='#18534F', command=lambda : self.recommencer(joueur_commence))
        self.bouton_recommencer.pack(pady=10)

        self.dessiner_grille()
        self.canvas.bind("<Button-1>", self.on_click)

    def dessiner_grille(self):
        self.canvas.delete("all") # supprime la grille si il y en a une
        for ligne in range(6):
            for col in range(7):
                x1 = col * 100
                y1 = ligne * 100
                x2 = x1 + 100
                y2 = y1 + 100
                self.canvas.create_rectangle(x1, y1, x2, y2, fill='#D6955B', outline='#D6955B')
                self.dessiner_pions(ligne, col, self.jeu.grille[ligne][col])

    def dessiner_pions(self, ligne, col, joueur_numero):
        x = col * 100 + 50
        y = ligne * 100 + 50
        couleur = 'white' 
        if joueur_numero == 1:
            couleur = self.jeu.joueurs[0].couleur
        elif joueur_numero == 2:
            couleur = self.jeu.joueurs[1].couleur
        self.canvas.create_oval(x-40, y-40, x+40, y+40, fill=couleur, outline='white')

    def on_click(self, event):
        col = event.x // 100 # chaque colonne fait 100 de largeur
        ligne, col, gagne = self.jeu.jouer(col)
        if ligne is not None:
            self.dessiner_pions(ligne, col, self.jeu.grille[ligne][col])
            if gagne:
                message_victoire = f"Le joueur {self.jeu.joueur_actuel.nom} a gagné !"
                message_scores = (f"Score de {self.jeu.joueurs[0].nom} : {self.jeu.joueurs[0].score} - "
                                f"Score de {self.jeu.joueurs[1].nom} : {self.jeu.joueurs[1].score}")
                self.afficher_message(f"{message_victoire}\n{message_scores}")
                self.canvas.unbind("<Button-1>")  # désactive les clics après la fin du jeu
            elif self.jeu.match_nul():
                message_victoire = f"Match nul..."
                message_scores = (f"Score de {self.jeu.joueurs[0].nom} : {self.jeu.joueurs[0].score} | "
                                f"Score de {self.jeu.joueurs[1].nom} : {self.jeu.joueurs[1].score}")
                self.afficher_message(f"{message_victoire}\n{message_scores}")
                self.canvas.unbind("<Button-1>")
    
    def recommencer(self, joueur_commence):
        self.jeu = Puissance4(self.joueur1, self.joueur2, joueur_commence)
        self.dessiner_grille()
        self.afficher_message("")
        # réactiver les clics sur la grille
        self.canvas.bind("<Button-1>", self.on_click)
    
    def afficher_message(self, message):
        self.message_label.config(text=message)
