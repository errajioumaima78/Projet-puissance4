import tkinter as tk
from demarrage import Demarrage

if __name__ == "__main__":
    fenetre_principale = tk.Tk()
    app_demarrage = Demarrage(fenetre_principale)
    fenetre_principale.mainloop()
