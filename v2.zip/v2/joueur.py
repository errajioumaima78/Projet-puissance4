class Joueur:
    def __init__(self, nom, couleur, numero):
        self.nom = nom
        self.couleur = couleur
        self.numero = numero 
        self.score = 0

    def gagner_partie(self):
        self.score += 1


