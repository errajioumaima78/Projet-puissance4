import tkinter as tk
from tkinter import colorchooser
from joueur import Joueur
from puissance4GUI import Puissance4GUI
from PIL import Image, ImageTk

class Demarrage:
    def __init__(self, fenetre_principale):
        self.fenetre_principale = fenetre_principale
        self.fenetre_principale.title("Configuration du Puissance 4")
        self.fenetre_principale.config(bg='#18534F')

        self.frame = tk.Frame(fenetre_principale, bg='#18534F', padx=10, pady=10)  # cadre pour ajouter une marge interne
        self.frame.pack(padx=20, pady=20)  # marge externe autour du cadre

        # nom du Joueur 1
        tk.Label(self.frame, text="Nom du Joueur 1 :   ", font=("Caviar Dreams", 20), bg='#18534F', fg='#FEEAA1').grid(row=0, column=0, sticky="w")
        self.nom_joueur1 = tk.Entry(self.frame)
        self.nom_joueur1.grid(row=0, column=1, pady=(20,40))
        
        image = Image.open("v2\choisir.png")
        gradient_photo = ImageTk.PhotoImage(image)

        # couleur du Joueur 1
        tk.Label(self.frame, text="Couleur du Joueur 1 :   ", font=("Caviar Dreams", 20), bg='#18534F', fg='#FEEAA1').grid(row=1, column=0, sticky="w")
        self.couleur_joueur1 = tk.Entry(self.frame)
        self.couleur_joueur1.grid(row=1, column=1)
        bouton_couleur1 = tk.Button(self.frame, image=gradient_photo, command=lambda: self.choisir_couleur(self.couleur_joueur1))
        bouton_couleur1.grid(row=1, column=2)
        bouton_couleur1.image = gradient_photo
        
        # Nom du Joueur 2
        tk.Label(self.frame, text="Nom du Joueur 2 :   ", font=("Caviar Dreams", 20), bg='#18534F', fg='#FEEAA1').grid(row=2, column=0, sticky="w")
        self.nom_joueur2 = tk.Entry(self.frame)
        self.nom_joueur2.grid(row=2, column=1, pady=(20,40))

        # Couleur du Joueur 2
        tk.Label(self.frame, text="Couleur du Joueur 2 :   ", font=("Caviar Dreams", 20), bg='#18534F', fg='#FEEAA1').grid(row=3, column=0, sticky="w")
        self.couleur_joueur2 = tk.Entry(self.frame)
        self.couleur_joueur2.grid(row=3, column=1)
        bouton_couleur2 = tk.Button(self.frame, image=gradient_photo, command=lambda: self.choisir_couleur(self.couleur_joueur2))
        bouton_couleur2.grid(row=3, column=2)
        bouton_couleur2.image = gradient_photo
        
        # choisir qui commance
        tk.Label(self.frame, text="Joueur qui commence :   ", font=("Caviar Dreams", 20), bg='#18534F', fg='#FEEAA1').grid(row=4, column=0, sticky="w", pady=(30,0))
        self.joueur_commence = tk.StringVar(value="Joueur 1") # mettre le bouton au joueur1
        tk.Radiobutton(self.frame, text="Joueur 1", variable=self.joueur_commence, value="Joueur 1", font=("Caviar Dreams", 16), bg='#18534F').grid(row=4, column=1, pady=(30,0))
        tk.Radiobutton(self.frame, text="Joueur 2", variable=self.joueur_commence, value="Joueur 2", font=("Caviar Dreams", 16), bg='#18534F').grid(row=4, column=2, pady=(30,0))

        # Bouton pour démarrer le jeu
        self.bouton_demarrer = tk.Button(self.frame, text="Démarrer le jeu", command=self.demarrer_jeu, bg='#FEEAA1', fg='#18534F', font=("Caviar Dreams", 20))
        self.bouton_demarrer.grid(row=5, column=0, columnspan=2, pady= 40, padx=(100,0))

        # Centrer la fenêtre au démarrage
        self.centrer_fenetre()

    def demarrer_jeu(self):
        joueur1 = Joueur(self.nom_joueur1.get(), self.couleur_joueur1.get(), 1)
        joueur2 = Joueur(self.nom_joueur2.get(), self.couleur_joueur2.get(), 2)
        
        if self.joueur_commence.get() == "Joueur 1":
            joueur_commence = joueur1
        else:
            joueur_commence = joueur2

        self.fenetre_principale.destroy() # Fermer la fenêtre de configuration

        fenetre_jeu = tk.Tk()
        Puissance4GUI(fenetre_jeu, joueur1, joueur2, joueur_commence)
        fenetre_jeu.mainloop()
        
    def choisir_couleur(self, couleur_choisie):
        couleur = colorchooser.askcolor(title="Choisir une couleur") #retourne un tuple : la couleur et True ou False
        if couleur[1]:
            couleur_choisie.delete(0, tk.END) # supprime l'ancienne couleur
            couleur_choisie.insert(0, couleur[1]) # insère la nouvelle couleur choisie
            
    def centrer_fenetre(self):
        self.fenetre_principale.update_idletasks() # attends la fin des tâches en attente
        
        largeur_fenetre = self.fenetre_principale.winfo_width() # largeur de la fenetre principale
        hauteur_fenetre = self.fenetre_principale.winfo_height()
        
        position_x = (self.fenetre_principale.winfo_screenwidth() // 2) - (largeur_fenetre // 2) #position honrizontale : divise la taille de l'ecran en 2
        position_y = (self.fenetre_principale.winfo_screenheight() // 2) - (hauteur_fenetre // 2) #position verticale
        
        self.fenetre_principale.geometry('{}x{}+{}+{}'.format(largeur_fenetre, hauteur_fenetre, position_x, position_y))

