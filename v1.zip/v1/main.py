import tkinter as tk
from puissance4GUI import Puissance4GUI
from joueur import Joueur

if __name__ == "__main__":
    root = tk.Tk()
    joueur1 = Joueur("Alice", "red", 1)
    joueur2 = Joueur("Bob", "yellow", 2)
    app = Puissance4GUI(root, joueur1, joueur2)
    root.mainloop()
