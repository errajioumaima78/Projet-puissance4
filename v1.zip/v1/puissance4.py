class Puissance4:
    def __init__(self, joueur1, joueur2, lignes=6, cols=7):
        self.lignes = lignes
        self.cols = cols
        self.grille = [[0 for _ in range(cols)] for _ in range(lignes)]
        self.joueurs = [joueur1, joueur2]
        self.joueur_actuel = joueur1

    def jouer(self, col):
        for ligne in range(self.lignes - 1, -1, -1):
            if self.grille[ligne][col] == 0:
                self.grille[ligne][col] = self.joueur_actuel.numero
                gagne = self.gagner(ligne, col)
                if gagne:
                    return ligne, col, True
                self.joueur_actuel = self.joueurs[0] if self.joueur_actuel.numero == 2 else self.joueurs[1]
                return ligne, col, False
        return None, None, False


    def gagner(self, ligne, col):
        # horizontalement
        for c in range(max(col-3, 0), min(col+4, self.cols-3)):
            if all(self.grille[ligne][c+i] == self.joueur_actuel.numero for i in range(4)):
                self.joueur_actuel.score +=1
                return True

        # verticalement
        if ligne <= self.lignes - 4:
            if all(self.grille[ligne+i][col] == self.joueur_actuel.numero for i in range(4)):
                self.joueur_actuel.score +=1
                return True

        # diagonalement /
        for r in range(max(ligne-3, 0), min(ligne+4, self.lignes-3)):
            for c in range(max(col-3, 0), min(col+4, self.cols-3)):
                if all(self.grille[r+i][c+i] == self.joueur_actuel.numero for i in range(4)):
                    self.joueur_actuel.score +=1
                    return True

        # diagonalement \
        for r in range(min(ligne+3, self.lignes-1), max(ligne-4, -1), -1):
            for c in range(max(col-3, 0), min(col+4, self.cols-3)):
                if all(self.grille[r-i][c+i] == self.joueur_actuel.numero for i in range(4)):
                    self.joueur_actuel.score +=1
                    return True

        return False
    
    def match_nul(self):
        compte_non_nul = 0
        
        for ligne in range(self.lignes):
            for col in range(self.cols):
                if self.grille[ligne][col] != 0:
                    compte_non_nul += 1
        
        total_cases = self.lignes * self.cols
        
        if compte_non_nul == total_cases:
            return True
        else:
            return False

