class Puissance4:
    def __init__(self, lignes=6, cols=7):
        self.lignes = lignes
        self.cols = cols
        self.grille = [[0 for _ in range(cols)] for _ in range(lignes)]
        self.joueur_actuel = 1

    def afficher_grille(self):
        for ligne in self.grille:
            print(' | '.join(str(x) if x != 0 else ' ' for x in ligne))
            print('-' * (self.cols * 4 - 1))

    def jouer(self, col):
        for ligne in range(self.lignes - 1, -1, -1):
            if self.grille[ligne][col] == 0:
                self.grille[ligne][col] = self.joueur_actuel
                return ligne, col, self.gagner(ligne, col)
        return None, None, False

    def gagner(self, ligne, col):
        # Horizontalement, Verticalement, Diagonalement /, \
        directions = [(0, 1), (1, 0), (1, 1), (1, -1)]
        for dx, dy in directions:
            compteur = 0
            for i in range(-3, 4):
                x, y = ligne + i*dx, col + i*dy
                if 0 <= x < self.lignes and 0 <= y < self.cols and self.grille[x][y] == self.joueur_actuel:
                    compteur += 1
                    if compteur == 4:
                        return True
                else:
                    compteur = 0
        return False
    
    def match_nul(self):
        return all(self.grille[ligne][col] != 0 for ligne in range(self.lignes) for col in range(self.cols))

    def lancer_jeu(self):
        jeu_en_cours = True
        while jeu_en_cours:
            self.afficher_grille()
            col = int(input(f"Joueur {self.joueur_actuel}, choisissez une colonne: ")) - 1
            ligne, col, gagne = self.jouer(col)
            if gagne:
                self.afficher_grille()
                print(f"Le joueur {self.joueur_actuel} a gagné!")
                jeu_en_cours = False
            elif self.match_nul():
                self.afficher_grille()
                print("Match nul!")
                jeu_en_cours = False
            self.joueur_actuel = 3 - self.joueur_actuel