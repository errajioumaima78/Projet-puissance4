from puissance4 import Puissance4

if __name__ == "__main__":
    jeu = Puissance4()
    jeu.lancer_jeu()
